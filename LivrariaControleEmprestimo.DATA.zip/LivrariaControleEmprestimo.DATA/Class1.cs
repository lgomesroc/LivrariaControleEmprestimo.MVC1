﻿namespace LivrariaControleEmprestimo.DATA
{
    public class Class1
    {

    }
}
